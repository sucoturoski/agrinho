function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let player;
let city;
let resources = [];
let score = 0;
let gameTimer = 60; // Tempo em segundos
let timerInterval;
let gameState = 'start'; // 'start', 'playing', 'win', 'lose'
let collectedResource = null; // Para saber qual recurso o jogador está carregando
let deliveryEffectTimer = 0; // Timer para o efeito de entrega na cidade

// Configurações do jogo
const NUM_RESOURCES = 10;
const RESOURCE_BASE_RADIUS = 20;
const PLAYER_SPEED = 5;
const PLAYER_BASE_RADIUS = 15;
const CITY_WIDTH = 150;
const CITY_HEIGHT = 150;

function setup() {
  createCanvas(800, 600);
  rectMode(CENTER);
  textAlign(CENTER, CENTER);
  textSize(24);

  player = {
    x: width / 2,
    y: height - 50,
    width: 40, // Largura do trator
    height: 30 // Altura do trator
  };

  city = {
    x: width / 2,
    y: height / 2,
    width: CITY_WIDTH,
    height: CITY_HEIGHT
  };

  generateResources();
}

function draw() {
  background(220); // Cor de fundo suave

  if (gameState === 'start') {
    drawStartScreen();
  } else if (gameState === 'playing') {
    drawPlayingScreen();
  } else if (gameState === 'win') {
    drawWinScreen();
  } else if (gameState === 'lose') {
    drawLoseScreen();
  }
}

function drawStartScreen() {
  fill(0);
  text("Festejando a Conexão: Campo e Cidade", width / 2, height / 3);
  textSize(18);
  text("Colete os recursos do campo e leve-os para a cidade (centro).", width / 2, height / 2.5 + 30);
  text("Use as setas do teclado para mover o trator.", width / 2, height / 2.5 + 60);
  text("Pressione ENTER para começar!", width / 2, height / 2 + 50);
}

function drawPlayingScreen() {
  // Desenha o campo (superior e inferior)
  drawField();

  // Desenha recursos
  for (let i = 0; i < resources.length; i++) {
    let r = resources[i];
    drawResource(r);
  }

  // Desenha a cidade
  drawCity();

  // Desenha o jogador (trator)
  drawPlayer();

  // Indica se o jogador está carregando um recurso
  if (collectedResource) {
    fill(255, 255, 0); // Amarelo para indicar recurso carregado
    ellipse(player.x, player.y - player.height / 2 - 10, 10); // Pequeno círculo acima do trator
  }

  // Movimento do jogador
  handlePlayerMovement();

  // Colisão com recursos
  handleResourceCollection();

  // Entrega na cidade
  handleCityDelivery();

  // Desenha informações do jogo
  fill(0);
  textSize(20);
  text(`Pontuação: ${score}`, 80, 30);
  text(`Tempo: ${floor(gameTimer)}s`, width - 80, 30);

  // Verifica condição de perda por tempo
  if (gameTimer <= 0 && gameState === 'playing') {
    gameState = 'lose';
    clearInterval(timerInterval);
  }

  // Desenha o efeito de entrega se estiver ativo
  if (deliveryEffectTimer > 0) {
    drawDeliveryEffect();
    deliveryEffectTimer--;
  }
}

function drawWinScreen() {
  fill(0, 150, 0); // Verde para vitória
  text("VITÓRIA!", width / 2, height / 3);
  textSize(20);
  text(`Você entregou ${score} recursos!`, width / 2, height / 2.5 + 30);
  text("Pressione ENTER para jogar novamente!", width / 2, height / 2 + 50);
}

function drawLoseScreen() {
  fill(150, 0, 0); // Vermelho para derrota
  text("FIM DE JOGO!", width / 2, height / 3);
  textSize(20);
  text(`Tempo esgotado! Você entregou ${score} recursos.`, width / 2, height / 2.5 + 30);
  text("Pressione ENTER para jogar novamente!", width / 2, height / 2 + 50);
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (gameState === 'start' || gameState === 'win' || gameState === 'lose') {
      resetGame();
    }
  }
}

function handlePlayerMovement() {
  if (keyIsDown(LEFT_ARROW)) {
    player.x -= PLAYER_SPEED;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    player.x += PLAYER_SPEED;
  }
  if (keyIsDown(UP_ARROW)) {
    player.y -= PLAYER_SPEED;
  }
  if (keyIsDown(DOWN_ARROW)) {
    player.y += PLAYER_SPEED;
  }

  // Limita o jogador à tela
  player.x = constrain(player.x, player.width / 2, width - player.width / 2);
  player.y = constrain(player.y, player.height / 2, height - player.height / 2);
}

function handleResourceCollection() {
  if (!collectedResource) { // Só pode coletar se não estiver carregando um
    for (let i = resources.length - 1; i >= 0; i--) {
      let r = resources[i];
      // Colisão entre círculo (recurso) e retângulo (jogador simplificado)
      // Simplificando para colisão de círculo para círculo para o trator
      let d = dist(player.x, player.y, r.x, r.y);
      if (d < PLAYER_BASE_RADIUS + r.radius) { // Usando PLAYER_BASE_RADIUS para a colisão
        collectedResource = r; // Armazena o recurso coletado
        resources.splice(i, 1); // Remove o recurso do array
        break; // Coleta apenas um por vez
      }
    }
  }
}

function handleCityDelivery() {
  if (collectedResource) { // Só pode entregar se estiver carregando algo
    // Verifica colisão com a cidade (retângulo)
    if (player.x > city.x - city.width / 2 &&
      player.x < city.x + city.width / 2 &&
      player.y > city.y - city.height / 2 &&
      player.y < city.y + city.height / 2) {

      score++; // Aumenta a pontuação
      collectedResource = null; // Libera o recurso
      deliveryEffectTimer = 30; // Ativa o efeito de entrega por 30 frames
      // Opcional: Gerar um novo recurso imediatamente ou esperar para manter o desafio
      // generateSingleResource();
    }
  }
}

function generateResources() {
  resources = []; // Limpa recursos existentes
  for (let i = 0; i < NUM_RESOURCES; i++) {
    // Posiciona recursos fora da área da cidade
    let x, y;
    let validPosition = false;
    while (!validPosition) {
      x = random(RESOURCE_BASE_RADIUS, width - RESOURCE_BASE_RADIUS);
      y = random(RESOURCE_BASE_RADIUS, height - RESOURCE_BASE_RADIUS);

      // Garante que o recurso não está na área da cidade
      if (!(x > city.x - city.width / 2 - RESOURCE_BASE_RADIUS &&
          x < city.x + city.width / 2 + RESOURCE_BASE_RADIUS &&
          y > city.y - city.height / 2 - RESOURCE_BASE_RADIUS &&
          y < city.y + city.height / 2 + RESOURCE_BASE_RADIUS)) {
        validPosition = true;
      }
    }

    resources.push({
      x: x,
      y: y,
      radius: RESOURCE_BASE_RADIUS,
      color: color(random(100, 255), random(100, 255), random(100, 255)) // Cores mais vibrantes
    });
  }
}

function startTimer() {
  timerInterval = setInterval(() => {
    gameTimer--;
    if (gameTimer <= 0) {
      clearInterval(timerInterval);
      if (gameState === 'playing') {
        gameState = 'lose'; // Se o tempo acabar, perde
      }
    }
    // Condição de vitória: se todos os recursos foram entregues
    if (score === NUM_RESOURCES && gameState === 'playing') {
      gameState = 'win';
      clearInterval(timerInterval);
    }
  }, 1000); // A cada 1 segundo
}

function resetGame() {
  score = 0;
  gameTimer = 60;
  collectedResource = null;
  deliveryEffectTimer = 0;
  generateResources();
  player.x = width / 2;
  player.y = height - 50;
  gameState = 'playing';
  clearInterval(timerInterval); // Limpa qualquer timer anterior
  startTimer(); // Inicia o timer novamente
}

// --- Funções de Desenho Elaboradas ---

function drawField() {
  // Campo superior
  fill(100, 150, 50); // Verde para o campo
  rect(width / 2, height * 0.25, width, height * 0.5);
  // Linhas de cultivo no campo superior
  stroke(80, 130, 40); // Verde mais escuro para as linhas
  for (let y = height * 0.05; y < height * 0.5; y += 15) {
    line(0, y, width, y);
  }
  noStroke();

  // Campo inferior
  fill(100, 150, 50); // Verde para o campo
  rect(width / 2, height * 0.75, width, height * 0.5);
  // Linhas de cultivo no campo inferior
  stroke(80, 130, 40); // Verde mais escuro para as linhas
  for (let y = height * 0.5 + 15; y < height - 15; y += 15) {
    line(0, y, width, y);
  }
  noStroke();
}

function drawCity() {
  // Base da cidade
  fill(150, 150, 150); // Cinza para a cidade
  rect(city.x, city.y, city.width, city.height);

  // Silhueta de prédios
  let buildingColors = [color(120), color(130), color(140)];
  let buildingHeights = [city.height * 0.6, city.height * 0.8, city.height * 0.7, city.height * 0.9, city.height * 0.65];
  let buildingWidth = city.width / (buildingHeights.length + 1);

  for (let i = 0; i < buildingHeights.length; i++) {
    let bX = city.x - city.width / 2 + (i + 1) * buildingWidth;
    let bY = city.y - city.height / 2 + (city.height - buildingHeights[i]) / 2;
    fill(buildingColors[i % buildingColors.length]);
    rect(bX, bY + buildingHeights[i] / 2, buildingWidth * 0.8, buildingHeights[i]);

    // Janelas (quadrados aleatórios)
    fill(0); // Janelas escuras
    for (let j = 0; j < buildingHeights[i] / 15; j++) {
      for (let k = 0; k < 2; k++) {
        let windowX = bX - buildingWidth * 0.2 + k * buildingWidth * 0.4;
        let windowY = bY + 10 + j * 15;
        if (random(1) > 0.7) { // Algumas janelas acendem
          fill(255, 255, 100); // Amarelo claro para janelas acesas
        } else {
          fill(50); // Cinza escuro para janelas apagadas
        }
        rect(windowX, windowY, 8, 8);
      }
    }
  }

  fill(0);
  textSize(16);
  text("CIDADE", city.x, city.y - city.height / 2 - 10);
  text("PONTO DE ENTREGA", city.x, city.y + city.height / 2 + 10);
}

function drawPlayer() {
  push(); // Salva o estado atual das transformações
  translate(player.x, player.y);

  // Corpo do trator
  fill(50, 150, 50); // Verde escuro
  rect(0, 0, player.width, player.height); // Corpo principal

  // Cabine
  fill(70, 170, 70); // Verde mais claro
  rect(player.width / 4, -player.height / 2 - 5, player.width / 2, player.height / 2);

  // Rodas
  fill(30); // Preto
  ellipse(-player.width / 2 + 5, player.height / 2 - 5, 15, 15); // Roda dianteira
  ellipse(player.width / 2 - 5, player.height / 2 - 5, 20, 20); // Roda traseira

  // Efeito de motor (pulso)
  let pulse = map(sin(frameCount * 0.1), -1, 1, 0, 5); // Pulsa de 0 a 5
  fill(255, 200, 0, 150); // Amarelo transparente
  ellipse(player.width / 2 + 10, -player.height / 2, 8 + pulse); // Pequeno brilho do motor

  pop(); // Restaura o estado salvo
}

function drawResource(r) {
  push();
  translate(r.x, r.y);
  // Animação de pulso para o recurso
  let pulse = map(sin(frameCount * 0.05 + r.x * 0.01), -1, 1, 0, 5); // Pulsa de 0 a 5, com offset para variação
  fill(r.color);
  ellipse(0, 0, r.radius * 2 + pulse);
  pop();
}

function drawDeliveryEffect() {
  let alpha = map(deliveryEffectTimer, 0, 30, 0, 255); // Fades out
  let size = map(deliveryEffectTimer, 0, 30, CITY_WIDTH * 0.8, CITY_WIDTH * 1.2); // Grows

  noFill();
  stroke(255, 255, 0, alpha); // Amarelo brilhante
  strokeWeight(3);
  ellipse(city.x, city.y, size, size);
  noStroke();
}
